import React, { useEffect, useState } from 'react';

export type MapType = 'diffuse' | 'normal' | 'height' | 'roughness';

interface PreviewProps {
  canvases: {
    diffuse: React.RefObject<HTMLCanvasElement | null>;
    normal: React.RefObject<HTMLCanvasElement | null>;
    height: React.RefObject<HTMLCanvasElement | null>;
    roughness: React.RefObject<HTMLCanvasElement | null>;
  };
  generateTrigger: number;
}

export default function Preview({ canvases, generateTrigger }: PreviewProps) {
  const [activeTab, setActiveTab] = useState<MapType>('diffuse');
  const [seamlessUrl, setSeamlessUrl] = useState<string>('');

  const tabs: { id: MapType; label: string }[] = [
    { id: 'diffuse', label: 'Diffuse' },
    { id: 'normal', label: 'Normal' },
    { id: 'height', label: 'Height' },
    { id: 'roughness', label: 'Roughness' },
  ];

  useEffect(() => {
    // Update seamless preview when tab changes or generation happens
    const activeCanvas = canvases[activeTab].current;
    if (activeCanvas) {
      setSeamlessUrl(activeCanvas.toDataURL('image/png'));
    }
  }, [activeTab, generateTrigger, canvases]);

  return (
    <div className="flex flex-col items-center gap-2.5 w-full max-w-[520px]">
      {/* Tabs */}
      <div className="flex gap-0 rounded-t-md overflow-hidden w-full max-w-[512px] shadow-[0_2px_8px_rgba(0,0,0,0.4)]">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 p-[10px_4px] text-center cursor-pointer font-bold text-[13px] tracking-[0.5px] border-none m-0 rounded-none transition-colors duration-150 sm:text-[11px] sm:p-[9px_2px] sm:tracking-normal ${
              activeTab === tab.id
                ? 'bg-[#f5cf87] text-[#1e1e24]'
                : 'bg-[#2b2b36] text-[#999] hover:bg-[#3a3a48] hover:text-[#ddd]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Canvases */}
      <div className="relative w-full max-w-[512px] aspect-square">
        <canvas
          ref={canvases.diffuse}
          width={512}
          height={512}
          className={`absolute top-0 left-0 w-full h-full rounded-b-md bg-[#3a3b3a] border-2 border-[#555] shadow-[0_4px_15px_rgba(0,0,0,0.6)] ${
            activeTab !== 'diffuse' ? 'hidden' : ''
          }`}
        />
        <canvas
          ref={canvases.normal}
          width={512}
          height={512}
          className={`absolute top-0 left-0 w-full h-full rounded-b-md bg-[#3a3b3a] border-2 border-[#555] shadow-[0_4px_15px_rgba(0,0,0,0.6)] ${
            activeTab !== 'normal' ? 'hidden' : ''
          }`}
        />
        <canvas
          ref={canvases.height}
          width={512}
          height={512}
          className={`absolute top-0 left-0 w-full h-full rounded-b-md bg-[#3a3b3a] border-2 border-[#555] shadow-[0_4px_15px_rgba(0,0,0,0.6)] ${
            activeTab !== 'height' ? 'hidden' : ''
          }`}
        />
        <canvas
          ref={canvases.roughness}
          width={512}
          height={512}
          className={`absolute top-0 left-0 w-full h-full rounded-b-md bg-[#3a3b3a] border-2 border-[#555] shadow-[0_4px_15px_rgba(0,0,0,0.6)] ${
            activeTab !== 'roughness' ? 'hidden' : ''
          }`}
        />
      </div>

      <label className="text-[#f5cf87] font-bold mt-2">
        Test de Tuilage (Seamless) :
      </label>
      <div
        className="w-full max-w-[512px] h-[256px] sm:h-[40vw] border-2 border-[#f5cf87] rounded-md bg-repeat shadow-[inset_0_0_10px_rgba(0,0,0,0.5)]"
        style={{
          backgroundImage: seamlessUrl ? `url(${seamlessUrl})` : 'none',
          backgroundSize: '256px 256px',
        }}
      />
    </div>
  );
}
