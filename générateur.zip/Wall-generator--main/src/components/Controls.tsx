import React, { useState } from 'react';
import { GeneratorParams } from '../types';

interface ControlsProps {
  params: GeneratorParams;
  setParams: React.Dispatch<React.SetStateAction<GeneratorParams>>;
  onGenerate: () => void;
  onDownload: (type: 'diffuse' | 'normal' | 'height' | 'roughness') => void;
  onDownloadZip: () => void;
  isGeneratingZip: boolean;
}

export default function Controls({
  params,
  setParams,
  onGenerate,
  onDownload,
  onDownloadZip,
  isGeneratingZip,
}: ControlsProps) {
  const [collapsed, setCollapsed] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target;
    setParams((prev) => ({
      ...prev,
      [name]: type === 'range' ? parseFloat(value) : value,
    }));
  };

  return (
    <div className="bg-[#2b2b36] rounded-lg shadow-[0_4px_15px_rgba(0,0,0,0.6)] w-full max-w-[320px] flex flex-col sm:max-w-full md:max-w-[520px] lg:max-w-[320px]">
      <button
        className="lg:hidden bg-[#2b2b36] text-[#f5cf87] border border-[#444] rounded-md p-3 text-[15px] font-bold cursor-pointer w-full text-center hover:bg-[#3a3a48]"
        onClick={() => setCollapsed(!collapsed)}
      >
        <span
          className={`inline-block transition-transform duration-200 ${
            collapsed ? '-rotate-90' : ''
          }`}
        >
          ▼
        </span>{' '}
        Paramètres
      </button>

      <div
        className={`flex flex-col gap-2.5 p-5 ${
          collapsed ? 'hidden lg:flex' : 'flex'
        }`}
      >
        <div className="text-[#f5cf87] text-xs uppercase tracking-[1.5px] border-b border-[#444] pb-1 mt-2.5 mb-0.5">
          Maçonnerie
        </div>
        <div>
          <label className="text-[13px] font-bold text-[#d1d1d1] flex justify-between items-center">
            Nb. Lignes <span>{params.rows}</span>
          </label>
          <input
            type="range"
            name="rows"
            min="6"
            max="20"
            step="1"
            value={params.rows}
            onChange={handleChange}
            className="w-full accent-[#f5cf87] mt-1"
          />
        </div>
        <div>
          <label className="text-[13px] font-bold text-[#d1d1d1] flex justify-between items-center">
            Variété hauteurs <span>{params.heightVar}%</span>
          </label>
          <input
            type="range"
            name="heightVar"
            min="0"
            max="100"
            step="5"
            value={params.heightVar}
            onChange={handleChange}
            className="w-full accent-[#f5cf87] mt-1"
          />
        </div>
        <div>
          <label className="text-[13px] font-bold text-[#d1d1d1] flex justify-between items-center">
            Variété largeurs <span>{params.cols}</span>
          </label>
          <input
            type="range"
            name="cols"
            min="15"
            max="50"
            step="1"
            value={params.cols}
            onChange={handleChange}
            className="w-full accent-[#f5cf87] mt-1"
          />
        </div>
        <div>
          <label className="text-[13px] font-bold text-[#d1d1d1] flex justify-between items-center">
            Déformation contours <span>{params.roughness}%</span>
          </label>
          <input
            type="range"
            name="roughness"
            min="0"
            max="100"
            step="5"
            value={params.roughness}
            onChange={handleChange}
            className="w-full accent-[#f5cf87] mt-1"
          />
        </div>

        <div className="text-[#f5cf87] text-xs uppercase tracking-[1.5px] border-b border-[#444] pb-1 mt-2.5 mb-0.5">
          Mortier
        </div>
        <div>
          <label className="text-[13px] font-bold text-[#d1d1d1] flex justify-between items-center">
            Épaisseur <span>{params.gap}</span>
          </label>
          <input
            type="range"
            name="gap"
            min="2"
            max="20"
            step="1"
            value={params.gap}
            onChange={handleChange}
            className="w-full accent-[#f5cf87] mt-1"
          />
        </div>
        <div>
          <label className="text-[13px] font-bold text-[#d1d1d1] flex justify-between items-center">
            Couleur
            <input
              type="color"
              name="mortarColor"
              value={params.mortarColor}
              onChange={handleChange}
              className="border border-[#555] rounded p-0 w-10 h-6 cursor-pointer bg-transparent"
            />
          </label>
        </div>

        <div className="text-[#f5cf87] text-xs uppercase tracking-[1.5px] border-b border-[#444] pb-1 mt-2.5 mb-0.5">
          Relief & Texture
        </div>
        <div>
          <label className="text-[13px] font-bold text-[#d1d1d1] flex justify-between items-center">
            Biseau (Relief 3D) <span>{params.bevel}%</span>
          </label>
          <input
            type="range"
            name="bevel"
            min="0"
            max="100"
            step="5"
            value={params.bevel}
            onChange={handleChange}
            className="w-full accent-[#f5cf87] mt-1"
          />
        </div>
        <div>
          <label className="text-[13px] font-bold text-[#d1d1d1] flex justify-between items-center">
            Texture de surface <span>{params.texture}%</span>
          </label>
          <input
            type="range"
            name="texture"
            min="0"
            max="100"
            step="5"
            value={params.texture}
            onChange={handleChange}
            className="w-full accent-[#f5cf87] mt-1"
          />
        </div>
        <div>
          <label className="text-[13px] font-bold text-[#d1d1d1] flex justify-between items-center">
            Fissures <span>{params.cracks}%</span>
          </label>
          <input
            type="range"
            name="cracks"
            min="0"
            max="100"
            step="5"
            value={params.cracks}
            onChange={handleChange}
            className="w-full accent-[#f5cf87] mt-1"
          />
        </div>

        <div className="text-[#f5cf87] text-xs uppercase tracking-[1.5px] border-b border-[#444] pb-1 mt-2.5 mb-0.5">
          Normal Map
        </div>
        <div>
          <label className="text-[13px] font-bold text-[#d1d1d1] flex justify-between items-center">
            Intensité Normales <span>{params.normalStr.toFixed(1)}</span>
          </label>
          <input
            type="range"
            name="normalStr"
            min="0.5"
            max="5.0"
            step="0.1"
            value={params.normalStr}
            onChange={handleChange}
            className="w-full accent-[#f5cf87] mt-1"
          />
        </div>

        <button
          onClick={onGenerate}
          className="bg-[#c7a56a] text-[#111] border-none p-3 rounded cursor-pointer font-bold text-base transition-colors duration-200 mt-2.5 hover:bg-[#f5cf87]"
        >
          Générer le Mur
        </button>

        <div className="grid grid-cols-2 gap-1.5 w-full mt-1.5">
          <button
            onClick={() => onDownload('diffuse')}
            className="bg-[#558a62] p-[9px_6px] rounded border-none cursor-pointer font-bold text-xs text-white transition-all duration-200 text-center hover:brightness-125"
          >
            ↓ Diffuse
          </button>
          <button
            onClick={() => onDownload('normal')}
            className="bg-[#5a6e8a] p-[9px_6px] rounded border-none cursor-pointer font-bold text-xs text-white transition-all duration-200 text-center hover:brightness-125"
          >
            ↓ Normal
          </button>
          <button
            onClick={() => onDownload('height')}
            className="bg-[#7a7a7a] p-[9px_6px] rounded border-none cursor-pointer font-bold text-xs text-white transition-all duration-200 text-center hover:brightness-125"
          >
            ↓ Height
          </button>
          <button
            onClick={() => onDownload('roughness')}
            className="bg-[#8a7a5a] p-[9px_6px] rounded border-none cursor-pointer font-bold text-xs text-white transition-all duration-200 text-center hover:brightness-125"
          >
            ↓ Roughness
          </button>
          <button
            onClick={onDownloadZip}
            disabled={isGeneratingZip}
            className="col-span-2 bg-gradient-to-br from-[#7b5ea7] to-[#5a6e8a] p-[11px_6px] rounded border-none cursor-pointer font-bold text-[13px] text-white transition-all duration-200 text-center hover:brightness-125 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isGeneratingZip ? '⏳ Création du ZIP…' : '📦 Télécharger le Pack ZIP (4 maps)'}
          </button>
        </div>
      </div>
    </div>
  );
}
