import JSZip from 'jszip';
import React, { useEffect, useRef, useState } from 'react';
import Controls from './components/Controls';
import Preview from './components/Preview';
import { generateAllTextures } from './lib/generator';
import { GeneratorParams } from './types';

const defaultParams: GeneratorParams = {
  rows: 12,
  cols: 32,
  heightVar: 60,
  roughness: 45,
  gap: 8,
  mortarColor: '#b09870',
  bevel: 70,
  texture: 60,
  cracks: 40,
  normalStr: 2.0,
};

export default function App() {
  const [params, setParams] = useState<GeneratorParams>(defaultParams);
  const [generateTrigger, setGenerateTrigger] = useState(0);
  const [isGeneratingZip, setIsGeneratingZip] = useState(false);

  const canvases = {
    diffuse: useRef<HTMLCanvasElement>(null),
    normal: useRef<HTMLCanvasElement>(null),
    height: useRef<HTMLCanvasElement>(null),
    roughness: useRef<HTMLCanvasElement>(null),
  };

  const handleGenerate = () => {
    if (
      !canvases.diffuse.current ||
      !canvases.normal.current ||
      !canvases.height.current ||
      !canvases.roughness.current
    ) {
      return;
    }

    generateAllTextures(params, {
      diffuse: canvases.diffuse.current,
      normal: canvases.normal.current,
      height: canvases.height.current,
      roughness: canvases.roughness.current,
    });

    setGenerateTrigger((prev) => prev + 1);
  };

  // Initial generation
  useEffect(() => {
    handleGenerate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleDownload = (type: 'diffuse' | 'normal' | 'height' | 'roughness') => {
    const canvas = canvases[type].current;
    if (!canvas) return;

    const link = document.createElement('a');
    link.download = `mur_pierres_${type}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  const handleDownloadZip = async () => {
    setIsGeneratingZip(true);
    try {
      const zip = new JSZip();
      const maps = [
        { canvas: canvases.diffuse.current, name: 'mur_pierres_diffuse.png' },
        { canvas: canvases.normal.current, name: 'mur_pierres_normal.png' },
        { canvas: canvases.height.current, name: 'mur_pierres_height.png' },
        { canvas: canvases.roughness.current, name: 'mur_pierres_roughness.png' },
      ];

      for (const m of maps) {
        if (m.canvas) {
          const dataUrl = m.canvas.toDataURL('image/png');
          const base64 = dataUrl.split(',')[1];
          zip.file(m.name, base64, { base64: true });
        }
      }

      const blob = await zip.generateAsync({ type: 'blob' });
      const link = document.createElement('a');
      link.download = 'mur_pierres_pbr_pack.zip';
      link.href = URL.createObjectURL(blob);
      link.click();
      URL.revokeObjectURL(link.href);
    } catch (e: any) {
      alert('Erreur lors de la création du ZIP: ' + e.message);
    } finally {
      setIsGeneratingZip(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#1e1e24] text-[#eee] font-sans p-5 flex flex-col items-center">
      <h1 className="mt-0 text-[#f5cf87] text-center text-2xl mb-5 font-bold">
        Générateur de Pierres — PBR Maps
      </h1>

      <div className="flex flex-col md:flex-row gap-[30px] justify-center items-start w-full max-w-6xl">
        <Controls
          params={params}
          setParams={setParams}
          onGenerate={handleGenerate}
          onDownload={handleDownload}
          onDownloadZip={handleDownloadZip}
          isGeneratingZip={isGeneratingZip}
        />
        <Preview canvases={canvases} generateTrigger={generateTrigger} />
      </div>
    </div>
  );
}
